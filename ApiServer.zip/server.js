const apiKey='Your Unsplash API key';

const express=require('express');
const cors=require('cors');
const server=express();
const fetch = require('node-fetch');
server.use(express.urlencoded({extended:false}));
server.use(express.json());
server.use(cors());

server.post('/fetchImages',async(req,res)=>{
    const {count}=req.body;
    const apiUrl=`https://api.unsplash.com/photos/random?client_id=${apiKey}&count=${count}&content_filter=high`;
    const response=await fetch(apiUrl);
    const photosArray=await response.json();
    res.json(photosArray);
})
server.listen(process.env.PORT);